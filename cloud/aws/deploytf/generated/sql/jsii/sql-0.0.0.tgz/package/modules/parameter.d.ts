import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface ParameterConfig extends TerraformModuleUserConfig {
    /**
    * The names of the roles that can access the parameter
    */
    readonly accessRoleNames: string[];
    /**
    * The name of the parameter
    */
    readonly parameterName: string;
    /**
    * The text value of the parameter
    */
    readonly parameterValue: string;
}
/**
* Defines an Parameter based on a Terraform module
*
* Source at ./.nitric/modules/parameter
*/
export declare class Parameter extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: ParameterConfig);
    get accessRoleNames(): string[];
    set accessRoleNames(value: string[]);
    get parameterName(): string;
    set parameterName(value: string);
    get parameterValue(): string;
    set parameterValue(value: string);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
