import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface StackConfig extends TerraformModuleUserConfig {
    /**
    * Enable the creation of a website
    */
    readonly enableWebsite?: boolean;
    /**
    * The name of the project
    */
    readonly projectName: string;
    /**
    * The name of the stack
    */
    readonly stackName: string;
}
/**
* Defines an Stack based on a Terraform module
*
* Source at ./.nitric/modules/stack
*/
export declare class Stack extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: StackConfig);
    get enableWebsite(): boolean | undefined;
    set enableWebsite(value: boolean | undefined);
    get projectName(): string;
    set projectName(value: string);
    get stackName(): string;
    set stackName(value: string);
    get stackIdOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
