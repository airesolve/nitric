import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface WebsiteConfig extends TerraformModuleUserConfig {
    /**
    * The base path for the website files.
    */
    readonly basePath: string;
    /**
    * The error document for the website.
    * 404.html
    */
    readonly errorDocument?: string;
    /**
    * The index document for the website.
    * index.html
    */
    readonly indexDocument?: string;
    /**
    * The local directory containing website files.
    */
    readonly localDirectory: string;
    /**
    * The region where the bucket will be created.
    */
    readonly region: string;
    /**
    * The ID of the stack.
    */
    readonly stackId: string;
    /**
    * The name of the website.
    */
    readonly websiteName: string;
}
/**
* Defines an Website based on a Terraform module
*
* Source at ./.nitric/modules/website
*/
export declare class Website extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: WebsiteConfig);
    get basePath(): string;
    set basePath(value: string);
    get errorDocument(): string | undefined;
    set errorDocument(value: string | undefined);
    get indexDocument(): string | undefined;
    set indexDocument(value: string | undefined);
    get localDirectory(): string;
    set localDirectory(value: string);
    get region(): string;
    set region(value: string);
    get stackId(): string;
    set stackId(value: string);
    get websiteName(): string;
    set websiteName(value: string);
    get bucketNameOutput(): string;
    get errorDocumentOutput(): string;
    get fileMd5SOutput(): string;
    get indexDocumentOutput(): string;
    get localDirectoryOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
