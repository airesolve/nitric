import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface CdnConfig extends TerraformModuleUserConfig {
    /**
    * A map of API gateway configurations.
    */
    readonly apiGateways: any;
    /**
    * The CDN domain configuration.
    */
    readonly cdnDomain: any;
    /**
    * The project ID where resources will be created.
    */
    readonly projectId: string;
    /**
    * The region where resources will be created.
    */
    readonly region: string;
    /**
    * The unique identifier for the stack.
    */
    readonly stackId: string;
    /**
    * A map of website bucket configurations.
    */
    readonly websiteBuckets: any;
}
/**
* Defines an Cdn based on a Terraform module
*
* Source at ./.nitric/modules/cdn
*/
export declare class Cdn extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: CdnConfig);
    get apiGateways(): any;
    set apiGateways(value: any);
    get cdnDomain(): any;
    set cdnDomain(value: any);
    get projectId(): string;
    set projectId(value: string);
    get region(): string;
    set region(value: string);
    get stackId(): string;
    set stackId(value: string);
    get websiteBuckets(): any;
    set websiteBuckets(value: any);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
